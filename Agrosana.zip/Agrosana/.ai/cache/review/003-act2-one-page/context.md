# Contexto · 003-act2-one-page

## Criterios de aceptación

- [x] CA1 · Dado el sitio publicado, cuando abro `/act2/`, entonces se muestra la página completa y todo lo que usa (estilos, comportamiento e imágenes) está dentro de la carpeta de la actividad con la estructura de la constitución (P3), servido tal cual, sin paso de construcción.
- [x] CA2 · Dada cualquier posición de desplazamiento, cuando miro la parte superior, entonces veo el logotipo y el nombre "AgroSana" en el encabezado.
- [x] CA3 · Dado el menú de navegación, cuando elijo Inicio, Nosotros, Productos, Uso seguro o Contacto, entonces la página se desplaza a esa sección sin salir de la página y la dirección termina en el ancla de la sección.
- [x] CA4 · Dada una pantalla de 768 px o menos, cuando pulso el botón de menú, entonces los enlaces se muestran y el botón indica que el menú está abierto; al pulsarlo de nuevo o elegir un enlace, el menú se cierra.
- [x] CA5 · Dado que abro la página, cuando veo la sección principal, entonces tiene un título, una descripción, una imagen con texto alternativo y un botón "Ver productos" que lleva a la sección Productos.
- [x] CA6 · Dada la página, cuando la recorro, entonces encuentro al menos tres secciones de contenido del tema además de la principal y la de contacto: Nosotros, Productos y Uso seguro.
- [x] CA7 · Dada la sección Nosotros, cuando la veo, entonces hay al menos tres tarjetas, cada una con icono, título y texto.
- [x] CA8 · Dada la sección Productos, cuando la veo, entonces hay una tarjeta por cada uno de los cinco productos (Frutime, Bio pH, HydroSpeed CaB-Max, Surfatek, Prozycar) con foto, nombre, categoría y descripción breve.
- [x] CA9 · Dados los botones de categoría (Todos, Fertilizantes, Fungicidas, Coadyuvantes, Bioestimulantes), cuando elijo uno, entonces solo quedan visibles los productos de esa categoría, el botón elegido se marca como activo y se anuncia cuántos productos se muestran; "Todos" vuelve a mostrar los cinco.
- [x] CA10 · Dado un producto, cuando pulso "Ver detalles", entonces se abre una ventana con su foto, nombre, categoría, para qué sirve y la indicación de leer la etiqueta; se cierra con el botón de cerrar, al pulsar fuera de ella o con la tecla Esc, y el foco vuelve al botón que la abrió.
- [x] CA11 · Dada la sección Uso seguro, cuando la abro, entonces veo al menos cuatro recomendaciones y un botón "Ver más"; al pulsarlo aparecen recomendaciones adicionales y el botón cambia a "Ver menos"; al pulsarlo de nuevo se ocultan.
- [x] CA12 · Dada la sección Contacto, cuando la veo, entonces aparecen teléfono, correo, ubicación y horario con su icono; el teléfono se puede marcar con un toque y el botón "Solicitar asesoría" abre el correo del visitante con el destinatario y el asunto ya escritos; la página no pide ni guarda datos personales.
- [x] CA13 · Dado el final de la página, cuando lo veo, entonces hay un pie con el nombre de la empresa, el año, enlaces a las secciones y el aviso de leer siempre la etiqueta.
- [x] CA14 · Dada la página, cuando reviso sus iconos, entonces todos provienen de la librería de iconos aprobada (P5) y no hay ningún emoji.
- [x] CA15 · Dado un ancho de 360, 768 o 1440 px, cuando cargo la página, entonces no hay desplazamiento horizontal y las tarjetas se acomodan en una, dos o tres columnas según el espacio.
- [x] CA16 (abuso) · Como visitante malintencionado, intento que la página muestre contenido propio escribiendo código en la dirección (ancla o parámetros) → la página no lo interpreta ni lo inserta.
- [x] CA17 (abuso) · Como atacante que altera un recurso de terceros que la página carga, intento ejecutar código en ella → el navegador rechaza el recurso alterado porque no coincide con su huella de integridad.
- [x] CA18 · Dado que navego e interactúo con todas las funciones, cuando reviso la consola del navegador, entonces no hay errores, mensajes de depuración ni recursos que no carguen.

## Modelo de amenazas (plan)
Aplica: la página tiene entradas externas (la dirección URL) y carga un recurso de terceros.

| ID | Amenaza (STRIDE) | Categoría OWASP | Componente | Control | Test |
|---|---|---|---|---|---|
| TM1 | Tampering: un CDN comprometido sirve CSS alterado | A08:2025 Software and Data Integrity Failures | `<link>` de Font Awesome | `integrity="sha512-Evv84Mr4…"` + `crossorigin="anonymous"` + `referrerpolicy="no-referrer"` | E17 (archivo alterado → rechazado) · U2 |
| TM2 | Tampering/XSS: código en el ancla o parámetros de la URL que la página inserte | A05:2025 Injection | `js/app.js` | El JS no lee `location` para generar contenido; solo `textContent`; sin sinks | E16 (URL con carga → sin nodos inyectados ni diálogos) · U4 |
| TM3 | Information disclosure: la página recoge datos personales sin aviso | A06:2025 Insecure Design | `#contacto` | Sin formularios; contacto por `tel:` y `mailto:` que abre el cliente del propio visitante | E12 · U4 |

## Trazabilidad (plan)
| Criterio de aceptación | Cambio(s) | Test(s) |
|---|---|---|
| CA1: estructura en act2, sin build | `act2/*`, raíz sin `package.json` | unit U1, U5 · e2e E1 (`/act2/` responde 200 y carga todo) |
| CA2: logotipo y nombre siempre visibles | `index.html` encabezado, `estilos.css` (`position: sticky`) | e2e E2 (en 360, 768 y 1440 px) |
| CA3: menú con anclas internas | `index.html` nav | e2e E3 |
| CA4: menú móvil ≤ 768 px (desplegable por debajo de 1024 px) | `index.html`, `estilos.css`, `app.js` (menú) | e2e E4 (360 y 768 px; `Esc`; visible en 1440) |
| CA5: hero con título, descripción, imagen y botón | `index.html` `#inicio` (panel de etiqueta), `img/hydrospeed-cab-max.jpg` | e2e E5 (con franja y `dl`) · verificación manual: `#inicio` a 360/768/1440 px contra `system.html` |
| CA6: tres secciones de contenido | `index.html` (orden del sistema: Uso seguro, Productos, Nosotros) | e2e E6 (con orden) |
| CA7: tres tarjetas en Nosotros | `index.html`, `estilos.css` (tarjetas desiguales del sistema) | e2e E7 · verificación manual: `#nosotros` contra `system.html` |
| CA8: cinco productos con foto, nombre, categoría y descripción | `index.html`, `img/*.jpg` | e2e E8 |
| CA9: filtro por categoría con anuncio | `index.html`, `app.js` (filtro) | e2e E9 |
| CA10: modal de detalle con cierre y retorno de foco | `index.html` `<dialog>`, `app.js` (modal), `estilos.css` | e2e E10 |
| CA11: Ver más / Ver menos | `index.html`, `app.js` (ver más) | e2e E11 |
| CA12: contacto con tel, correo prellenado y sin datos personales | `index.html` `#contacto` | e2e E12 (incluye la nota de datos de ejemplo) · unit U4 |
| CA13: pie de página | `index.html` `footer` | e2e E13 |
| CA14: solo iconos Font Awesome, sin emojis | `index.html` | unit U3 · e2e E14 |
| CA15: responsivo 360/768/1440 | `estilos.css` | e2e E15 (columnas de las rejillas de `#nosotros` y `#productos`) · verificación manual: capturas en 360, 768 y 1440 px contra `docs/design/system.html` |
| CA16 (abuso): código en la URL no se interpreta | `app.js` | e2e E16 · unit U4 |
| CA17 (abuso): recurso alterado rechazado | `index.html` `<link integrity>` | e2e E17 · unit U2 |
| CA18: consola limpia y sin recursos rotos | todo `act2/` | e2e E1, E4, E9, E10, E11 (vigilan consola) · unit U4 (sin `console.*`) |
| TM1 | `<link integrity>` | e2e E17 |
| TM2 | `app.js` | e2e E16 |
| TM3 | `#contacto` | e2e E12 |
| RNF: accesibilidad WCAG 2.1 AA básica | `index.html`, `estilos.css`, `app.js` | e2e E18 (alt, contraste, foco visible, objetivos ≥ 44 px) · E10 · E4 |
| RNF: utilizable en 360/768/1440 | `estilos.css` | e2e E15 |
| RNF: sin errores de consola | `act2/` | e2e E1 |
| RNF: interfaz solo con el sistema de diseño (P12) | `estilos.css`, `index.html` | unit U6, U7 |
| RNF: tipografía de marca autoalojada y cargada | `act2/fonts/`, `estilos.css` | unit U1 · e2e E19 |
| RNF: un solo momento animado, con versión sin movimiento | `estilos.css` (franja) | e2e E20 · verificación manual: tablero `#estados` de `system.html` |

## Observabilidad (plan)
No aplica: la spec no toca datos sensibles, autenticación ni permisos, y el sitio no tiene servidor
propio. Única medida: el JS nuevo no escribe en consola (OB1.a, test U4); tras el deploy se revisa
que Vercel no registre respuestas 404 para `/act2/*`.
