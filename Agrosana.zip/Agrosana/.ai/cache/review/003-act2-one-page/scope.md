# Alcance · 003-act2-one-page · 87daefb..HEAD

Base: 87daefb (--base). Archivos de código cambiados: 7.

## Cambiados sin tarea que los cite (candidatos a alcance extra; verificar)

- ninguno

## Tareas con rutas que no aparecen en el diff (¿sin implementar o solo docs?)

- T001
- T002
- T003
- T004
- T005
- T012
- T013
- T015
- T016
- T019
- T020
- T021
- T027
- T034

## Generados por comando (fuera de code.diff; se revisa el comando de la tarea)

- act2/img/*.jpg: 0 archivos (tarea T003)
- act2/fonts/*: 0 archivos (tarea T004)

## Archivos cambiados (sin los generados)

```
M	act2/css/estilos.css
M	act2/js/app.js
M	tests/e2e/accesibilidad.spec.mjs
M	tests/e2e/basico.spec.mjs
M	tests/e2e/interaccion.spec.mjs
M	tests/unit/estructura.test.mjs
M	tests/unit/tokens-sistema.json
```
